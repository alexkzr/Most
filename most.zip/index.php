<?php

require_once __DIR__ . '/config.php';

// ─── Заголовки безопасности (до session_start) ────────────────────────────────
function applySecurityHeaders(): void {
    $nonce = base64_encode(random_bytes(16));
    $_SERVER['CSP_NONCE'] = $nonce;

    // CSP убран отсюда — он уже есть в .htaccess
    header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header_remove('X-Powered-By');
}

applySecurityHeaders();
// ─── Безопасные настройки сессии ─────────────────────────────────────────────
// Настраиваем ДО session_start()
ini_set('session.cookie_httponly', '1');   // JS не может читать куки — защита от XSS
ini_set('session.cookie_secure',   '1');   // Только по HTTPS
ini_set('session.cookie_samesite', 'Strict'); // Защита от CSRF через куки
ini_set('session.use_strict_mode', '1');   // Запрет принятия чужих session ID
ini_set('session.gc_maxlifetime',  '28800'); // Сессия живёт максимум 8 часов

session_name(SESSION_NAME);
session_start();

// ─── Роутер ───────────────────────────────────────────────────────────────────
$uri    = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri    = rtrim($uri, '/');
$method = $_SERVER['REQUEST_METHOD'];

// Если не авторизован — только страница логина
if (!isset($_SESSION['user_id']) && $uri !== '/login' && $uri !== '/login/2fa' && $uri !== '/logout') {
    header('Location: /login');
    exit;
}

// Если прошёл логин но не прошёл 2FA — только на /login/2fa
if (
    isset($_SESSION['pending_2fa']) &&
    $_SESSION['pending_2fa'] === true &&
    $uri !== '/login/2fa' &&
    $uri !== '/logout'
) {
    header('Location: /login/2fa');
    exit;
}

// Роутинг
match(true) {
    // Авторизация
    $uri === '/login'  => require __DIR__ . '/src/controllers/AuthController.php',
    $uri === '/login/2fa' => require __DIR__ . '/src/controllers/TwoFactorController.php',
    $uri === '/logout' => require __DIR__ . '/src/controllers/AuthController.php',

    // Главная — канбан или список
    ($uri === '' || $uri === '/') && ($_GET['view'] ?? 'board') === 'board' => require __DIR__ . '/src/controllers/BoardController.php',
    ($uri === '' || $uri === '/') && ($_GET['view'] ?? '') === 'list'       => require __DIR__ . '/src/controllers/ListController.php',

    // Задачи
    str_starts_with($uri, '/tasks') => require __DIR__ . '/src/controllers/TaskController.php',

    // Архив
    $uri === '/archive' => require __DIR__ . '/src/controllers/ArchiveController.php',

    // Настройки
    $uri === '/settings' => require __DIR__ . '/src/controllers/SettingsController.php',

    // API
    str_starts_with($uri, '/api') => require __DIR__ . '/src/controllers/ApiController.php',
    str_starts_with($uri, '/upload') => require __DIR__ . '/src/controllers/UploadController.php',

    // 404
    default => (function() {
        http_response_code(404);
        require __DIR__ . '/src/views/404.php';
    })()
};
